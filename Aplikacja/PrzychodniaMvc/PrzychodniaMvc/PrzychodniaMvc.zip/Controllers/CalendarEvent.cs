﻿using System;

namespace PrzychodniaMvc.Controllers
{
    internal class CalendarEvent
    {
        internal DateTime end_date;
        internal int id;
        internal DateTime start_date;
        internal string text;
    }
}